<?php
session_start();
error_reporting(0);
header("Cache-Control: no-cache, must-revalidate");
date_default_timezone_set("Asia/Kuala_Lumpur");

require_once("conf/db_conn.php");
include 'app/main.php';
 if (isset($_GET['loc']))
	{
  include 'app/' . $_GET['loc'] . '.php';
	} 
elseif (isset($_GET['q']))
	{
    include 'act/' . $_GET['q'] . '.php';
	}
else
	{
    include 'app/dashboard.html';
	}
?>


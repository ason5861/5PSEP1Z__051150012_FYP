

<BODY>
<div id="shopping-cart">
<div class="txt-heading">Check Out</div><br>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	

<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
</tr>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "RM ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "RM ". number_format($item_price,2); ?></td>
				</tr>
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>

<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><?php echo "RM ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tbody>
</table>
<br>
<div class="row">
                <div class="col-5" >
                    <div class="contact-form-area">
                        <form action="index.php?loc=saveContact" method="post">
                            <div class="row">
                                <div class="col-12">
                                    <input  name="name"  type="text" class="form-control" id="name" placeholder="Name">
                                </div>
                                <div class="col-12 ">
                                    <input  name="pn" type="text" class="form-control" id="pn" placeholder="Phone Number">
                                </div>
                                <div class="col-12">
                                    <input  name="email" type="email" class="form-control" id="email" placeholder="Email">
                                </div>
								<div class="col-12">
                                    <input  name="home_address" type="home_address" class="form-control" id="home_address" placeholder="Home Address">
                                </div>
                                <div class="col-12">
                                    <textarea name="remark" class="form-control" id="remark" cols="30" rows="10" placeholder="Remark"></textarea>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    
                </div>
                
            </div>

            <div class="col-12 text-center">
                                    <button class="btn delicious-btn mt-30" onclick='submitOrder()'>Order now</button>
                                </div>
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty</div>
<?php 
}
?>
</div>


<div style="
    display: grid;
    width: 100%;
    background-color: red;
"></div>
  <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-12 h-100 d-flex flex-wrap align-items-center justify-content-between">
                    <!-- Footer Social Info -->
                    <div class="footer-social-info text-right">
                        <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                    </div>
                    <!-- Footer Logo -->
                    <div class="footer-logo">
                        <a href="simple_php_shopping_cart/index.html"><img src="./img/core-img/logo.png" alt=""></a>
                    </div>
                    <!-- Copywrite -->
                    <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Misai Man</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                </div>
            </div>
        </div>
    </footer>
</BODY>
</HTML>
	
	
	
	
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

    <script >
        function submitOrder(){

// console.log($('#name').val());
// console.log($('#pn').val());
// console.log($('#email').val());
// console.log($('#remark').val());
var data = {name:$('#name').val(),pn:$('#pn').val(),email:$('#email').val(),home_address:$('#home_address').val(),remark:$('#remark').val(),total:<?php echo $total_price ?>,product:<?php echo json_encode($_SESSION["cart_item"]); ?>};
$.ajax({
    type: 'POST',
    url: 'act/checkout.php',
    data: data,
    //dataType:'json',
    beforeSend: function() {
  
    },
    success: function(data) {
        alert("order success")
    },
    error: function(xhr) { // if error occured
        console.log(xhr.statusText + xhr.responseText);
    },   
});
        }
        </script>
</body>

</html>
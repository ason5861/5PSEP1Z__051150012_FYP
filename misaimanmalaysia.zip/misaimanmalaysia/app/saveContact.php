<?php
session_start();
require_once("simple_php_shopping_cart/dbcontroller.php");
$db_handle = new DBController();

if(!empty($_POST["name"])&&!empty($_POST["email"])&&!empty($_POST["subject"])&&!empty($_POST["message"])) {
	$sql="INSERT INTO `contact`( `name`, `subject`, `message`, `email`) VALUES ('".$_POST['name']."','".$_POST['subject']."','".$_POST['email']."','".$_POST['message']."')";
	
	$db_handle->numRows($sql);
	?>
	<html><head></head><body style="
    text-align: center;
    height: fit-content;
    width: fit-content;
    margin: 200px auto auto auto;
"><div>
Your message have been stored<br><br>

<a href="index.php">Back to home</a>
</div>



</body></html>
<?php
}
?>


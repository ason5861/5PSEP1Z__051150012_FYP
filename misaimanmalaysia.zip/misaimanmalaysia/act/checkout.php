<?php 



require_once("../conf/dbcontroller.php");
//echo  "INSERT INTO  `order`  (`name`, `phoneNumber`, `email`, `remark`, `total`) VALUES ('".$_POST['name']."','".$_POST['pn']."','".$_POST['email']."','".$_POST['remark']."',".$_POST['total'].")";
$db_handle = new DBController();
			$order = $db_handle->insertQuery( "INSERT INTO `order` (`name`, `phoneNumber`, `email`,`address`,`remark`, `total`) VALUES ('".$_POST['name']."','".$_POST['pn']."','".$_POST['email']."','".$_POST['home_address']."','".$_POST['remark']."',".$_POST['total'].")");
	foreach  ($_POST["product"] as $item){

	$orderProduct = $db_handle->insertQuery( "INSERT INTO `orderproduct`( `order`, `product`, `quatity`, `cost`) VALUES (".$order.",".$item["code"].",".$item["quantity"].",".$item["price"].")");

}		

           
//echo $productByCode;

echo  $_POST['product'][0]['name'];

?>
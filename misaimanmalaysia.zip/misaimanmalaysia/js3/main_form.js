// Main Template JS

$(document).ready(function() {
	var height = $(window).height() - 180;
	$("#content_div").css("min-height", function(){ return height});
});

function dash() {
//	window.location = '?loc=dashboard';
}

function searchPopup(id, arg) {
	var popup = document.getElementById(id);
	// showLayer();
	document.getElementById('popuphtml').src = arg;
	popup.style.display = 'block';
}

function showPopup(id) {
	var popup = document.getElementById(id);
	popup.style.display = 'block';
}

function hidePopup(id) {
	var popup = document.getElementById(id);
	// hideLayer();
	popup.style.display = 'none';
}

function getBrowserHeight() {
	var intH = 0;
	var intW = 0;
	
	if(typeof window.innerWidth  == 'number' ) {
		intH = window.innerHeight;
		intW = window.innerWidth;
	} else if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
		intH = document.documentElement.clientHeight;
		intW = document.documentElement.clientWidth;
	} else if(document.body && (document.body.clientWidth || document.body.clientHeight)) {
		intH = document.body.clientHeight;
		intW = document.body.clientWidth;
	}
	
	return { width: parseInt(intW), height: parseInt(intH) };
}
/* 
function setLayerPosition() {
	var shadow = document.getElementById("shadow");
	var bws = getBrowserHeight();
	shadow.style.width = bws.width + "px";
	shadow.style.height = bws.height + "px";
	shadow = null;
}
function showLayer() {
	setLayerPosition();
	var shadow = document.getElementById("shadow");
	shadow.style.display = "block";
	shadow = null;
}
function hideLayer() {
	var shadow = document.getElementById("shadow");
	shadow.style.display = "none";
	shadow = null;
}
*/
// window.onresize = setLayerPosition;

function logout() {
	$.ajax({
		url:'?q=logoutAction',
		success:function(data){
			if (data == true) {
				window.location = '?loc=home';
			} else {
				alert('Error While Logging Out');
			}
		}
	})
}
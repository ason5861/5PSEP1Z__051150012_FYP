
/***********/
/* GENERAL */
/***********/

/*
 * @author Karpz @ Voxz
 * @date Tue Jul 22 14:15:21 2014
 * Global Variables
 */
var ERR_REQUIRED = 'Please fill in all of the required details';
var AJAX_ERR_MSG = 'Loading Fail. Please try again later.';

function currentDate() {
    var currentTime = new Date();
    var day = currentTime.getDate();
    var month = currentTime.getMonth() + 1;
    var year = currentTime.getFullYear();

    if (day < 10) {
        day = '0' + day;
    }
    if (month < 10) {
        month = '0' + month;
    }

    var currentDate = year + "-" + month + "-" + day;

    return currentDate;
}


function delete_1(id) {
    var a = confirm("Are you sure you want to remove?");
    var loc = getQueryVariable('loc');
    var action = 'delete2';
    if (a) {
        $.ajax({
            url: "?f=" + loc,
            type: 'POST',
            data: {
                id: id,
                action: action
            },
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                hide_overLay(data);
                window.location = "?loc=" + loc;
            }
        });
    }
}


function updatepw(form) {
	
    var error_msg = new Array();
    $("#" + form + " .blank").each(function() {
        if ($.trim($(this).val()) == "") {
            error_msg.push("The " + $(this).attr("title") + " should not be blank.");
        }
    });
    var loc = getQueryVariable('loc');
    var serialized = $('#' + form).serialize();
    var extra = '&action=updatepw';
    var form_data = serialized + extra;
    if (error_msg.length < 1) {
        $.ajax({
            type: 'POST',
            url: "?f=" + loc,
            data: form_data,
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    hide_overLay(data);
                    $('#change').prop('disabled', true);
                    console.log(data);

                    // hide_overLay("Updated successfully");
                    // window.location = "?loc=" + loc;
                } else {
                    hide_overLay("Error while saving.");
                }
            }
        });
    } else {
        alert(error_msg.join("\n"));
    }
}



function select_(id, div_id) {
    $("#" + div_id).html("");
    var loc = getQueryVariable('loc');
    var action = 'select';
    $.ajax({
        type: 'POST',
        url: "?f=" + loc,
        data: {
            id: id,
            action: action
        },
        success: function(data) {
            $("#" + div_id).html(data);
            $('#change').prop('disabled', false);
        }
    });
}


function select2_(id, div_id) {
    $("#" + div_id).html("");
    var loc = getQueryVariable('loc');
    var action = 'select2';
    $.ajax({
        type: 'POST',
        url: "?f=" + loc,
        data: {
            id: id,
            action: action
        },
        success: function(data) {
            $("#" + div_id).html(data);
            $('#change').prop('disabled', false);
        }
    });
}


function select2_(id, div_id) {
    $("#" + div_id).html("");
    var loc = getQueryVariable('loc');
    var action = 'select2';
    $.ajax({
        type: 'POST',
        url: "?f=" + loc,
        data: {
            id: id,
            action: action
        },
        success: function(data) {
            $("#" + div_id).html(data);
            $('#change').prop('disabled', false);
        }
    });
}
function update_(form) {
    var error_msg = new Array();
    $("#" + form + " .blank").each(function() {
        if ($.trim($(this).val()) == "") {
            error_msg.push("The " + $(this).attr("title") + " should not be blank.");
        }
    });
    var loc = getQueryVariable('loc');
    var serialized = $('#' + form).serialize();
    var extra = '&action=update';
    var form_data = serialized + extra;
    if (error_msg.length < 1) {
        $.ajax({
            type: 'POST',
            url: "?f=" + loc,
            data: form_data,
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    hide_overLay(data);
                    // hide_overLay("Updated successfully");
                    if (form == 'form2') {
                        $('#wtp_modal').modal('hide');
                    } else {
                        window.location = "?loc=" + loc;
                    }
                } else {
                    hide_overLay("Error while saving.");
                }
            }
        });
    } else {
        alert(error_msg.join("\n"));
    }
}

function save_(form) {
    var error_msg = new Array();
    $("#" + form + " .blank").each(function() {
        if ($.trim($(this).val()) == "") {
            error_msg.push("The " + $(this).attr("title") + " should not be blank.");
        }
    });
    var loc = getQueryVariable('loc');
    var serialized = $('#' + form).serialize();
    var extra = '&action=save';
    var form_data = serialized + extra;
    if (error_msg.length < 1) {
        $.ajax({
            type: 'POST',
            url: "?f=" + loc,
            data: form_data,
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    console.log(data);
                    hide_overLay(data);
                    //$('#save').prop('disabled',true);
                    window.location = "?loc=" + loc;
                } else {
                    hide_overLay(data);
                }
            }
        });
    } else {
        alert(error_msg.join("\n"));
    }
}



function save2_(form) {
    var error_msg = new Array();
    $("#" + form + " .blank").each(function() {
        if ($.trim($(this).val()) == "") {
            error_msg.push("The " + $(this).attr("title") + " should not be blank.");
        }
    });
    var loc = getQueryVariable('loc');
    var serialized = $('#' + form).serialize();
    var extra = '&action=save2';
    var form_data = serialized + extra;
    if (error_msg.length < 1) {
        $.ajax({
            type: 'POST',
            url: "?f=" + loc,
            data: form_data,
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    console.log(data);
                    hide_overLay(data);
                    //$('#save').prop('disabled',true);
                    window.location = "?loc=" + loc;
                } else {
                    hide_overLay(data);
                }
            }
        });
    } else {
        alert(error_msg.join("\n"));
    }
}


function delete_(id, active) {
    if (active == 1) {
        var a = confirm("Are you sure you want to deactivate?");
    } else if (active == 0) {
        var a = confirm("Are you sure you want to activate?");
    }
    var loc = getQueryVariable('loc');
    var action = 'delete';
    if (a) {
        $.ajax({
            url: "?f=" + loc,
            type: 'POST',
            data: {
                id: id,
                action: action
            },
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    hide_overLay(data);
                    $('#save').prop('disabled', true);
					console.log(data);
                    window.location = "?loc=" + loc;
                } else {
                    hide_overLay("Error while saving.");
                }
            }
        });
    }
}

function delete_categories(id, active,act) {
    if (active == 1) {
        var a = confirm("Are you sure you want to deactivate?");
    } else if (active == 0) {
        var a = confirm("Are you sure you want to activate?");
    }
    var loc = getQueryVariable('loc');
    var action = 'delete';
    if (a) {
        $.ajax({
            url: "?f=" + act,
            type: 'POST',
            data: {
                id: id,
                action: action
            },
            beforeSend: function() {
                show_overLay();
            },
            success: function(data) {
                if (data) {
                    hide_overLay(data);
                    $('#save').prop('disabled', true);
					console.log(data);
                    window.location = "?loc=" + loc;
                } else {
                    hide_overLay("Error while saving.");
                }
            }
        });
    }
}



function isAlphaKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 32 && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
        // alert('Please input alphabet only.');
        // $('.main_content_form').find('input, textarea').filter(':focus').prop('title', 'alphabet only');
        return false;
    } else {
        return true;
    }
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        // alert('Please input number only.');
        // $('.main_content_form').find('input, textarea').filter(':focus').prop('title', 'number only');
        return false;
    } else {
        return true;
    }
}

function isAmountKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && charCode != 46 && (charCode < 48 || charCode > 57)) { // 46 = '.'
        // alert('Please input amount only.');
        // $('.main_content_form').find('input, textarea').filter(':focus').prop('title', 'amount only');
        return false;
    } else {
        return true;
    }
}

function isPhoneKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && charCode != 45 && (charCode < 48 || charCode > 57)) { // 45 = '-'
        // alert('Please input phone number only.');
        // $('.main_content_form').find('input, textarea').filter(':focus').prop('title', 'phone number only');
        return false;
    } else {
        return true;
    }
}

// clear all data in form
function clearData() {
    var answer = confirm('Confirm to clear all data? (Notice: Page will be refreshed.)');
    if (answer) {
        // document.getElementById('myForm').reset();
        // $('.required').removeClass('errorBorder');
        // alert('Data Clear. Click OK to continue.');
        // focusFirst();

        var loc = getQueryVariable('loc');
        window.location.href = '?loc=' + loc;
        // location.reload(true);
    }
}
function clearPage(loc) {
    var answer = confirm('Confirm to clear all data? (Notice: Page will be refreshed.)');
    if (answer) {
        window.location.href = loc;
    }
}
function clearSearchFunc(form_id, tableplugin_id) {
    if (form_id == '' || form_id == undefined) {
        form_id = 'myForm';
    }
    if (tableplugin_id == '' || tableplugin_id == undefined) {
        tableplugin_id = 'tableplugin';
    }

    $('#' + form_id)[0].reset();
    $('#' + form_id).find('select').val('');
    var table = $('#' + tableplugin_id);
    if (table != undefined) {
        table.dataTable().fnClearTable();
    }

    defaultPeriod();
    $('#start_date, #end_date').prop('disabled', true);
    $('#' + form_id + ' .errorBorder').each(function () {
        $(this).removeClass('errorBorder');
    });

    $('#err_msg').hide();
    $('#view_btn, #down_btn').hide();
}

// focus on first element type appear in form
function focusFirst(form_id) {
    if (form_id == '' || form_id == undefined) {
        form_id = 'myForm';
    }
    $('#' + form_id).find('input, select, textarea').filter(':not(:disabled):visible:first').focus();
}

// remove errorBorder class for NON-required field(s)
function removeErrorBorder(form_id) {
    if (form_id == '' || form_id == undefined) {
        form_id = 'myForm';
    }
    $('#' + form_id).find('input, select, textarea').not('.required').removeClass('errorBorder');
}

function preventBack() {
    return "Are you sure you want to navigate away?\nData you have entered may not be saved.";
}
// window.onbeforeunload = preventBack;

function tblPlugin(tbl) {
    var oTable = $(tbl).dataTable({
        // 'bScrollCollapse': true,
        // 'bPaginate': true,
        // 'iDisplayLength': 5,
        'bJQueryUI': true,
        'sPaginationType': 'full_numbers',
        'oLanguage': {
            'oPaginate': {
                'sFirst': '<<',
                'sPrevious': '<',
                'sNext': '>',
                'sLast': '>>',
            }
        },
        'fnRowCallback': function (nRow, aData, iDisplayIndex) {
            $(nRow).attr('id', 'row_' + aData[0]);
            return nRow;
        }
    });

    return oTable;
}
function tblPlugin_all(tbl) {
    var oTable = $(tbl).dataTable({
        'bJQueryUI': true,
        'sPaginationType': 'full_numbers',
        'iDisplayLength': -1, // to display All entries
        'aLengthMenu': [[-1], ['All']],
        // 'aLengthMenu': [[25, 50, 100, -1], [25, 50, 100, 'All']],
        'oLanguage': {
            'oPaginate': {
                'sFirst': '<<',
                'sPrevious': '<',
                'sNext': '>',
                'sLast': '>>',
            }
        },
        'fnRowCallback': function (nRow, aData, iDisplayIndex) {
            $(nRow).attr('id', 'row_' + aData[0]);
            return nRow;
        }
    });

    return oTable;
}
function tblPlugin_scroll(tbl) {
    var oTable = $(tbl).dataTable({
        'bJQueryUI': true,
        'sPaginationType': 'full_numbers',
        'scrollX': true,
        'sScrollX': '100%',
        'sScrollXInner': 'auto',
        // 'aLengthMenu': [[10, 25, 50, -1], [10, 25, 50, 'All']],
        // 'bScrollCollapse': true,
        // 'iDisplayLength': 50
        'oLanguage': {
            'oPaginate': {
                'sFirst': '<<',
                'sPrevious': '<',
                'sNext': '>',
                'sLast': '>>',
            }
        }
    });

    new FixedColumns(oTable, {
        'iLeftColumns': 1,
        'iLeftWidth': 45,
        'iRightColumns': 0,
        'iRightWidth': 0,
        'sHeightMatch': 'auto'
    });

    return oTable;
}
function tblPlugin_mth(tbl) {
    var oTable = $(tbl).dataTable({
        'bJQueryUI': true,
        'sPaginationType': 'full_numbers',
        'iDisplayLength': 12,
        'aLengthMenu': [[12, 24, 36, 48, 60], [12, 24, 36, 48, 60]],
        'oLanguage': {
            'oPaginate': {
                'sFirst': '<<',
                'sPrevious': '<',
                'sNext': '>',
                'sLast': '>>',
            }
        },
        'fnRowCallback': function (nRow, aData, iDisplayIndex) {
            $(nRow).attr('id', 'row_' + aData[0]);
            return nRow;
        }
    });

    return oTable;
}

function tblPlugin_length(tbl, length) {
    var oTable = $(tbl).dataTable({
        'bJQueryUI': true,
        'sPaginationType': 'full_numbers',
        'iDisplayLength': length, // 50
        'oLanguage': {
            'oPaginate': {
                'sFirst': '<<',
                'sPrevious': '<',
                'sNext': '>',
                'sLast': '>>',
            }
        },
    });
}

function uploadifyPlugin(input, loc) {
    $(input).uploadify({
        'uploader': './uploadify/uploadify.swf',
        'script': '?f=' + loc,
        'cancelImg': './uploadify/cancel.png',
        'folder': './upload/' + loc + '/temp',
        'multi': true,
        'auto': true,
        'fileExt': '*.jpg;*.jpeg;*.gif;*.png;*.pdf;*.csv;*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;',
        'fileDesc': 'Allowed Files (.JPG, .JPEG, .GIF, .PNG, .PDF, .CSV, .DOC, .DOCX, .XLS, .XLSX, .PPT, .PPTX)',
        'removeCompleted': true,
        'removeTimeout': 10,
        'width': 120,
        'onComplete': function (event, ID, fileObj, response, data) {
            if (response != 0) {
                var fname = response.substr(0, (response.search(",")));
                if (no_uploaded == 0) {
                    $("#title_uploaded").html("<p style='text-align: center; font-size: 18pt; font-weight: bold;'>Uploaded Files</p>");
                }

                no_uploaded++;

                // var remark_box = "<div class='remark_box'>Remark:<br /><br /><textarea class='remark_text' id='remark_txt_" + ++no_upload + "'></textarea></div>";
                var remove_link = "<div style='width: 9.5%; float: left; text-align: right;'><a href='#' onclick='delete_file(0)'>Remove</a></div><input type='hidden' id='n1_' name='n1_' value='" + response.substr((response.search(",") + 1), (response.length - (response.search(",") - 1))) + "' />";
                // var file_tag = "<div class='file_details' id='ufile_" + no_upload + "'><p><b>" + response + "</b></p>" + remove_link  + remark_box + "</div>";
                var file_tag = "<div class='file_details' id='ufile_'><div style='width: 90%; float: left;'><b>" + fname + "</b></div>" + remove_link + "<input type='hidden' name='n2_' id='n2_' value='" + fname + "' /></div>";

                $("#div_uploaded").html(file_tag);
            } else {
                alert("Invalid File or Size!");
            }
        },
        'onUploadError': function (file, errorCode, errorMsg, errorString) {
            alert('The file ' + file.name + ' could not be uploaded: ' + errorString);
        },
        'onUploadComplete': function (file) {
            alert('The file ' + file.name + ' finished processing.');
        }
    });
}

// filter dataTable once the page load/refresh
function viewRow(url) {
    var para = $('#tableplugin_filter input[type="text"]').val();
    var link = url + '&para=' + para;
    // alert(link);
    window.location.href = link;
}
function loadPara(tableId) {
    var oTable = $(tableId).dataTable();
    var para = getQueryVariable('para');
    // alert(para);
    if (para != '') {
        oTable.fnFilter(para);
    }
}

function pad_zeros(value) {
    //sets everything to at least two decimals; removes 3+ zero decimas, keeps non-zero decimals
    var new_value = value * 1; // removes trailing zeros
    new_value = new_value + ''; // casts it to string
    pos = new_value.indexOf('.');

    if (pos == -1) {
        new_value = new_value + '.00';
    } else {
        var integer = new_value.substring(0, pos);
        var decimals = new_value.substring(pos + 1);
        while (decimals.length < 2) {
            decimals = decimals + '0';
        }
        new_value = integer + '.' + decimals;
    }
    return new_value;
}

function checkIfEmptyAmount(obj) {
    var new_value = obj.value;
    if (new_value == '') {
        new_value = '0.00';
    } else {
        new_value = isNaN(new_value) ? '0.00' : pad_zeros(new_value);
        // new_value = pad_zeros(new_value);
    }
    obj.value = new_value;
    // obj.value = numberFormat(new_value);
}

function checkIfValidPerc(obj) {
    var new_value = obj.value;
    if (new_value > 100) {
        new_value = '100';
    }
    obj.value = new_value;
}
//function checkDuplicate(value, tbl, fld_name) {
//	$.ajax({
//		type: 'POST',
//		url: '?f=check_duplicate',
//		dataType : 'json',
//		data: {
//			value	: value,
//			tbl		: tbl,
//			fld_name : fld_name
//		},
//		success: function(data) {
//			//alert(data[0].row);
//			//alert(data.length);
//			if (data.length > 0) {
//				alert(data[0].row);
//			}
//		},
//		error: function(data) {
//			alert(AJAX_ERR_MSG);
//		}
//	});
//}
function numberFormat(number) {
    /* var n = number.toString().split("."); // Seperates the components of the number
     n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ","); // Comma-fies the first part
     return n.join("."); // Combines the two sections */
    var parts = number.split('.');
    var part1 = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
    var part2 = parts[1];
    number = part1 + '.' + part2;
    return number;
}

function special_char_replace(input) {
    var txt = input;
    txt = txt.replace(/&amp;/gi, '&');
    txt = txt.replace(/&#39;/gi, "\'");
    txt = txt.replace(/&#34;/gi, '\"');
    txt = txt.replace(/<br>/gi, "\n");
    return txt;
}

function special_char(input) {
    var txt = input;
    txt = txt.replace(/&/gi, '&amp;');
    txt = txt.replace(/\'/gi, "&#39;");
    txt = txt.replace(/\"/gi, '&#34;');
    txt = txt.replace(/\n/gi, "<br>");
    return txt;
}

// grab a value from &url
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1];
        }
    }
    return(false);
}

function show_overLay() {
    $('body').prepend('<div id="msg_alert"></div>');
}

function hide_overLay(success_msg) {
    if (success_msg != '') {
        alert(success_msg);
    }
    $('#msg_alert').hide();
}

function dataTbl_loading(tbl_id, td_colspan) {
    $(tbl_id).dataTable().fnClearTable();
    $(tbl_id + ' tbody').empty();
    $(tbl_id + ' tbody').append('<tr><td colspan="' + td_colspan + '"><center><img id="loading_gif" src="images/loading_fb.gif"></center></td></tr>');
}

function dataTbl_success(tbl_id) {
    $(tbl_id).dataTable().fnClearTable();
}

function prepend_errorMsg(err_msg, prependTo) {
    if ($('#err_msg').length) {
        remove_errorMsg();
    }
    if (prependTo == '' || prependTo == undefined) {
        prependTo = '.ht_right';
    }
    //console.log(prependTo);
    $("html, body").animate({scrollTop: 0}, "slow");
    $(prependTo).prepend('<span class="error_prepend" id="err_msg"><span class="i_warning"></span>' + err_msg + '<span>');
    $('#err_msg').fadeOut(20000);
}

function remove_errorMsg() {
    $('#err_msg').remove();
    $('.main_content_form').find('input, select, textarea').removeClass('errorBorder');
}


/**********/
/* CUSTOM */
/**********/

function viewPopup(file) {
    window.open('?f=list_popup&file=' + file + '&popup=true', '_blank');
}

//function viewFunc(act_file, filter_id, form_id) {
//    if (form_id == '' || form_id == undefined) {
//        form_id = 'myForm';
//    }
//    var myform = '#' + form_id;
//    var loading_gif = $(myform + ' #loading_gif');
//    var form_data = 'action=view&filter_id=' + filter_id;
//    var disabled = $(myform).find(':input:disabled').removeAttr('disabled');
//
//    $.ajax({
//        dataType: 'json',
//        type: 'POST',
//        url: '?f=' + act_file,
//        data: form_data,
//        beforeSend: function () {
//            // show_overLay();
//            loading_gif.show();
//            // remove_errorMsg();
//
//            $(myform).find('input[type="text"], input[type="password"], select, textarea').val('');
//            $("html, body").animate({scrollTop: 0}, "slow");
//        },
//        success: function (data) {
//            loading_gif.hide();
//            disabled.prop('disabled', true);
//
//            // alert(data.id);
//            $.each(data, function (key, value) {
//                var isNumeric = $.isNumeric(key);
//                if (isNumeric == false) {
//                    $(myform + ' #' + key).val(value);
//                }
//                // $(myform + ' #' + key + '_' + value).prop('checked', true); // use only for checkboxes and radios
//
//                // $(myform + ' #' + key + '_' + value).attr('selected','selected');
//                // console.log(key + ': ' + value);
//            });
//
//            $(myform + ' #filter_id').val(data.id);
//            $(myform + ' #btn_save').val('Update');
//            $(myform + ' #btn_cancel').val('Cancel');
//
//            viewFunc_extra(act_file, filter_id, form_id);
//        },
//        error: function (data) {
//            loading_gif.hide();
//            alert(AJAX_ERR_MSG);
//        }
//    })
//}

function viewFunc_extra(act_file, filter_id, form_id) {
    // extra features for viewFunc()
}

function deleteFunc(filter_id) {
    var action = 'delete';
    var loc = getQueryVariable('loc');

    var result = confirm('Confirm to delete selected record?');
    if (result) {
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: '?f=' + loc,
            data: {
                loc: loc,
                action: action,
                filter_id: filter_id
            },
            beforeSend: function () {
                // loading_gif.show();
                show_overLay();
            },
            success: function (data) {
                hide_overLay(data.msg);
                location.reload(true);
            },
            error: function (data) {
                // loading_gif.hide();
                hide_overLay(AJAX_ERR_MSG);
            }
        })
    }
}

// alert message when data failed to load
// x remove, just not sure why this is not working
function alertmsgFail(msg) {
    // alert('Loading Fail. Error: ' + data.error);
    var message = 'Loading Fail.';
    message = (msg != '') ? msg : message;
    alert(message);
}

// pop up a search result
function search_popup(file, extra) {
    // document.getElementById('person').reset();
    var url = '?f=search_popup&t=' + file;
    var url2 = url + extra;
    url = (extra != '') ? url2 : url;
    showLayer();
    $.get(url, function (data) {
        $("#popup_content").html(data);
        setLayerPosition2();
    });
    window.scrollTo(0, 0);
    // var url = "?f=search_popup&t=" + file + extra;
    // window.open(url, 'mywindow', 'location=1, status=1, scrollbars=1, width=1000, height=700');
}

//round up value to specified point
function precise_round(num, decimals) {
    var sign = num >= 0 ? 1 : -1;
    return (Math.round((num * Math.pow(10, decimals)) + (sign * 0.001)) / Math.pow(10, decimals)).toFixed(decimals);
}

//WARNING: Alter/Modifying this function might affect these files :app/fin_acc_rec_allocate.php
//renumber table rows
function renumber(tableId) {
    $('#' + tableId).find('tbody tr').each(function (i, v) {
        $(v).find('span.num').text(i + 1);
    });
}

//WARNING: Alter/Modifying this function might affect these files :app/fin_acc_rec_allocate.php
//dynamically adding a new row to table
function addTblRow(tableId, row) {
    $('#' + tableId).append(row);
    renumber(tableId);
}

//WARNING: Alter/Modifying this function might affect these files :app/fin_acc_rec_allocate.php
//delete table row
function delTblRow(r, tableId) {
    var i = r.parentNode.parentNode.rowIndex;

    var del_ans = confirm('Confirm to delete row number ' + (i - 1) + '?');
    // var del_ans = true;
    if (del_ans) {
        document.getElementById(tableId).deleteRow(i);
        //alert('Successfully deleted row number ' + (i) + '.');
        renumber(tableId);
    }
}

//discount a value and append it
function discount(value, percentage, appendTo) {
    var beforeDiscount = $('#' + value).val();
    var discount = beforeDiscount * ($('#' + percentage).val() / 100);
    var afterDiscount = beforeDiscount - discount;
    $('#' + appendTo).val(precise_round(afterDiscount, 2));
}
//printing
function printPage(className, reportName) {
    var html = "<html><head>";
    html += "<link rel='stylesheet' href='css/global.css' type='text/css' />";
    html += "<link rel='stylesheet' href='css/layout_theme/main.css' type='text/css' />";
    html += "<link rel='stylesheet' href='css/custom.css' type='text/css' />";
    html += "<title>" + reportName + "</title>";
    html += "<body style='background : #fff;'>";
    html += $('.' + className).html();
    html += "</body>";
    html += "</html></head>";
    var printWin = window.open(this.href);
    printWin.document.write(html);
    //printWin.document.close();
    //printWin.focus();
    //printWin.print();
    //printWin.close();
    printWin.stop();
}

function defaultPeriod() {
    $('#period').val('today');

    $('#start_date, #end_date').val(currentDate());
    $('#start_dt, #end_dt').val(currentDate());

    $('#start_date, #end_date').prop('disabled', true);
    $('#start_dt, #end_dt').prop('disabled', true);
}
function customPeriod(range) {
    var dept_site_id = $('#dash_op_site').val();
    if ($('#dash_op_site').val() === undefined) {
        dept_site_id = '';
    }

    $('#start_dt, #end_dt').val('');
    // date
    $('#start_date, #end_date').val('');

    if (range == 'custom') {
        $('#start_dt, #end_dt').prop('readonly', false);
        // date
        $('#start_date, #end_date').prop('readonly', false);
    } else if (range == 'all') {
        $('#start_dt, #end_dt').prop('readonly', true);
        // date
        $('#start_date, #end_date').prop('readonly', true);
    } else {
        $('#start_dt, #end_dt').prop('readonly', true);
        // date
        $('#start_date, #end_date').prop('readonly', true);
        if (range != '') {
            showRange(range, '', '', dept_site_id);
        }
    }
}
function customPeriod2(range) {
    var dept_site_id = $('#dash_op_site').val();
    if ($('#dash_op_site').val() === undefined) {
        dept_site_id = '';
    }

    $('#start_dt2, #end_dt2').val('');
    // date
    $('#start_date2, #end_date2').val('');

    if (range == 'custom') {
        $('#start_dt2, #end_dt2').prop('readonly', false);
        // date
        $('#start_date2, #end_date2').prop('readonly', false);
    } else if (range == 'all') {
        $('#start_dt2, #end_dt2').prop('readonly', true);
        // date
        $('#start_date2, #end_date2').prop('readonly', true);
    } else {
        $('#start_dt2, #end_dt2').prop('readonly', true);
        // date
        $('#start_date2, #end_date2').prop('readonly', true);
        if (range != '') {
            showRange2(range, '', '', dept_site_id);
        }
    }
}
/* function startRange() {
 var d1 = $('#start_date').val();
 var d2 = $('#end_date').val();
 if (d1 != '' && d2 != '') {
 showRange('custom', d1, d2);
 }
 } */
function showRange(range, d1, d2, dept_site_id) {
    var loading_gif = $('#loading_gif_period');
    $.ajax({
        dataType: 'json',
        type: 'POST',
        url: '?f=custom_period',
        data: {
            range: range,
            d1: d1,
            d2: d2,
            dept_site_id: dept_site_id
        },
        beforeSend: function () {
            loading_gif.show();
        },
        success: function (data) {
            loading_gif.hide();
            $('#start_dt').val(data.date1);
            $('#end_dt').val(data.date2);

            $('#start_date').val(data.date1);
            $('#end_date').val(data.date2);
        },
        error: function (data) {
            alert(AJAX_ERR_MSG);
        }
    })
}
function showRange2(range, d1, d2, dept_site_id) {
    var loading_gif = $('#loading_gif_period');
    $.ajax({
        dataType: 'json',
        type: 'POST',
        url: '?f=custom_period',
        data: {
            range: range,
            d1: d1,
            d2: d2,
            dept_site_id: dept_site_id
        },
        beforeSend: function () {
            loading_gif.show();
        },
        success: function (data) {
            loading_gif.hide();
            $('#start_dt2').val(data.date1);
            $('#end_dt2').val(data.date2);

            $('#start_date2').val(data.date1);
            $('#end_date2').val(data.date2);
        },
        error: function (data) {
            alert(AJAX_ERR_MSG);
        }
    })
}

function clearRec() {
    $('#search')[0].reset();
}

function toggle_expand(icon_id, div_id) {
    var btn = $('.toggle_btn').parent();
    img = $('#' + icon_id);
    var img_src = img.attr('src');
    div = $('#' + div_id);
    var div_display = div.css('display');
    if (div_display == 'none') {
        div.css('display', '');
    } else {
        div.css('display', 'none');
    }
    if (img_src == 'images/icon_circle_minus.png') {
        btn.find(img).attr('src', 'images/icon_circle_add.png');
        img.attr('title', 'Expand');
    } else {
        btn.find(img).attr('src', 'images/icon_circle_minus.png');
        img.attr('title', 'Collapse');
    }
}
function expandables(curr_div_id, next_div_id) {
    var valid = true;
    var next_div = $('#' + next_div_id);
    var curr_div = $('#' + curr_div_id);

    $('#' + curr_div_id).find('.required').each(function () {
        var inputVal = $(this).val();
        if (inputVal == '' || inputVal == '0.00') {
            $(this).addClass('errorBorder');
            valid = false;
        } else {
            $(this).removeClass('errorBorder');
        }
    });
    if (valid) {
        //curr_div.hide();
        curr_div.find('.hide_onclick').hide();
        next_div.show();
        next_div.find('.required').removeClass('errorBorder');
    } else {
        alert("Please enter the required fields.");
    }

}
function get_items_value(table_name) {
    var checkbox_value = '';
    var oTable = $('#' + table_name).dataTable();
    var rowcollection = oTable.$(".checkall:checked", {"page": "all"});
    rowcollection.each(function (index, elem) {
        checkbox_value += $(elem).val() + ',';
    });
    return checkbox_value.slice(0, -1);
}

function html_pdf_form_submit(table_name, type, url_name, ind_id, start_dt, end_dt, er_type) {
    var url = '';
    var value = '';
    if (ind_id != '') {
        value = ind_id;
    } else {
        value = get_items_value(table_name);
    }
    $('#form_value').val(value);
    $('#form_start_dt').val($('#' + start_dt).val());
    $('#form_end_dt').val($('#' + end_dt).val());
    $('#form_er_type').val(er_type);

    if (type == 'html') {
        url = 'html_' + url_name;
    } else if (type == 'pdf') {
        url = 'pdf_' + url_name;
    }

    $('#form_url').val(url + '.php');
    $('#html_pdf_form').submit();
}

// By Chuilynn
// Use for bulk printing
function html_pdf_form_bulk_submit(type, url_name, bulk_month, bulk_year, bulk_type, bulk_month_print, bulk_include_water, bulk_limit, bulk_count, bulk_count_ori, bulk_print_by, bulk_print_by_id, bulk_unique_id) {
    var url = '';
    if (type == 'html') {
        url = 'html_' + url_name;
    } else if (type == 'pdf') {
        url = 'pdf_' + url_name;
    }
    $('#form_bulk_month').val(bulk_month);
    $('#form_bulk_year').val(bulk_year);
    $('#form_bulk_type').val(bulk_type);
    $('#form_bulk_month_print').val(bulk_month_print);
    $('#form_bulk_include_water').val(bulk_include_water);
    $('#form_bulk_limit').val(bulk_limit);
    $('#form_bulk_count').val(bulk_count);
    $('#form_bulk_count_ori').val(bulk_count_ori);
    $('#form_bulk_print_by').val(bulk_print_by);
    $('#form_bulk_print_by_id').val(bulk_print_by_id);
    $('#form_bulk_unique_id').val(bulk_unique_id);
    $('#form_url').val(url + '.php');
    $('#html_pdf_form').submit();
}

// By Chuilynn
// Use for bulk printing
function html_pdf_form_bulk_submit2(url, bulk_month, bulk_year, bulk_type, bulk_month_print, bulk_include_water, bulk_limit, bulk_count, bulk_count_ori, bulk_print_by, bulk_print_by_id, bulk_unique_id) {
    $('#form_bulk_month').val(bulk_month);
    $('#form_bulk_year').val(bulk_year);
    $('#form_bulk_type').val(bulk_type);
    $('#form_bulk_month_print').val(bulk_month_print);
    $('#form_bulk_include_water').val(bulk_include_water);
    $('#form_bulk_limit').val(bulk_limit);
    $('#form_bulk_count').val(bulk_count);
    $('#form_bulk_count_ori').val(bulk_count_ori);
    $('#form_bulk_print_by').val(bulk_print_by);
    $('#form_bulk_print_by_id').val(bulk_print_by_id);
    $('#form_bulk_unique_id').val(bulk_unique_id);
    $('#form_url').val(url);
    $('#html_pdf_form').submit();
}

function autocomplete_emp() {
    $('#emp_name').autocomplete({
        source: '?f=autocomplete&type=emp',
        minLength: 1,
        select: function (event, ui) {
            var selectedObj = ui.item;
            var value = selectedObj.value;
            var label = selectedObj.label;
            // var split_label = label.split(']');

            // $('#emp_id').val(selectedObj.emp_id);
            $('#emp_id').val(selectedObj.emp_no);
            $('#emp_no').val(selectedObj.emp_no);
            $('#emp_name').val(selectedObj.emp_name);
            $('#emp_position').val(selectedObj.emp_position);
        }
    });
}
function autocomplete_course() {
    $('#course_title').autocomplete({
        source: '?f=autocomplete&type=course',
        minLength: 1,
        select: function (event, ui) {
            var selectedObj = ui.item;
            var value = selectedObj.value;
            var label = selectedObj.label;
            // var split_label = label.split(']');

            $('#course_id').val(selectedObj.course_id);
            $('#course_title').val(selectedObj.course_title);
            $('#course_location').val(selectedObj.course_location);
            // $('#course_date').val(selectedObj.course_date);
            // $('#course_trainer').val(selectedObj.course_trainer);
        }
    });
}

function show_tooltip() {
    var doc = $(document).height();
    var popup = parseInt($(".plugindiv").height()) + parseInt($(".plugindiv").position().top + parseInt($("#tooltip").height()));
    var difference = doc - popup;
    var total;

    if (difference >= 0) {
        total = 0;
    } else {
        total = difference;
    }
    //$('#tooltip').show();
    $(document).mousemove(function (e) {
        $('#tooltip').show();
        $('#tooltip').css({
            left: e.pageX + 20,
            top: e.pageY + total
        });
    });


}
function check_required(formName) {

    var required_fields = $('#' + formName + ' .required');
    if (formName == '' || formName == undefined) {
        var required_fields = $('.required');
    }
    var is_filled = true;
    required_fields.each(function () {
        var input_val = $(this).val().trim();
        if (input_val == '' || input_val == '0') {
            is_filled = false;
            $(this).addClass('errorBorder');
            prepend_errorMsg(ERR_REQUIRED);
        } else {
            $(this).removeClass('errorBorder');
        }
    });
    return is_filled;
}
function hide_tooltip() {
    $(document).mousemove(function () {
        $('#tooltip').hide();
    });
}
function validate_excel(formName) {
    if (!formName) {
        formName = '';
    }

    var fileName = $(formName + ' #file_upload').val();
    var fileName_split = fileName.split(".");
    $('#import').hide();
    remove_errorMsg();
    if (fileName_split[1] == 'xls' || fileName_split[1] == 'xlsx') {
        $(formName + ' #choose_file').val('Change File');
        $(formName + ' #valid_fileName').text(fileName);
        $(formName + ' #import').show();
    } else {
        prepend_errorMsg(fileName + ' is an Invalid File Format', formName + ' #invalid_err');
    }
}

function allow_form_close(user_type) {
    var allow_close = false;
    if (user_type == '1') {
        allow_close = true;
    }
    return allow_close;
}

//app/ncr_closure & app/ncr_closure_she
function form_closure(allow_to_close) {
    if (allow_to_close) {
        $('#form_list').show();
    } else {
        $('#form_div').show();
    }
}

function dash_to_report() {
    var start_date = getQueryVariable('start_date');
    var end_date = getQueryVariable('end_date');

    if (start_date != '' && end_date != '') {
        $('#period').val('custom');
        $('#start_date').val(start_date);
        $('#end_date').val(end_date);
        $('#start_date, #end_date').prop('disabled', false);

        // $('#li_view1').removeClass('selected');
        // $('#view1').hide();
        // $('#li_view2').addClass('selected');
        // $('#view2').show();

        // searchAcc();
        searchFunc();
    } else {
        //defaultPeriod();
    }
}
function browseFile() {
    var required = check_required();
    if (required) {
        $("#file_upload").click();
    }
}

function clearDataExtra(url, refresh) {
    var answer = confirm('Confirm to clear all data? (Notice: Page will be refreshed.)');
    if (answer) {
        window.location = '?loc=' + url + '&refresh=' + refresh;
    }
}

function browseFile() {
    var required = check_required();
    if (required) {
        $("#file_upload").click();
    }
}


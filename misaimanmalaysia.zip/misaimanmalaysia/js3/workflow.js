function displaytable(arg, typ) {
    var b = $("#" + arg + " option:selected").html();
    var c = $("#" + arg + " option:selected").val();
    if (typ == 1) {
        $('#tabledata').dataTable().fnFilter(c);
    }
    if (typ == 2) {
        $('#tabledata').dataTable().fnFilter(b);
    }
    if (typ == 3) {
        if (window.optionfiltering) {
            optionfiltering(c, b);
        }
    }
    //alert(b + ',' + c);
}
function validate_txt(fieldname, fieldvalue, alphaExp) {
    /** accept only 0-9 a-z A-Z _ . without space
     eg. var alphaExp1 = /^[0-9a-zA-Z_.]+$/;
     
     eg2. var reg = new RegExp("^[0-9a-zA-Z_.]+$");
     eg3. var reg2 = new RegExp("[0-9a-zA-Z_.]","g");
     */

    var reg = new RegExp("^" + alphaExp + "+$"); // for matching
    var reg2 = new RegExp("" + alphaExp + "", "g"); // for strip
    var err = '';
    fieldvalue = fieldvalue.trim();
    if (fieldvalue.match(reg)) { //or if(fieldvalue.match(alphaExp1)){
        //check if fieldvalue contain illegal value
    } else {

        var c = fieldvalue.replace(reg2, '');
        /** - direct method
         var c = fieldvalue.replace(/[^0-9A-Za-z_.]/g,'');
         var d = fieldvalue;
         var e = '';
         for(var i=0;i<c.length;i++){
         e = c.substr(i,1);
         d = d.replace(e,'');
         }
         */
        err += '*<font color="blue">Invalid Char</font> ' + c.trim() + ' <font color="blue">in</font> ' + $('#lbl_' + fieldname).html() + '</br>';
    }
    if (fieldvalue.length >= 4 && fieldvalue.length <= 30) {
        //check if fieldvalue length between 4-30 char
    } else {
        err += '*<font color="blue">Length Of</font> ' + $('#lbl_' + fieldname).html() + ' <font color="blue">out of bound</font> 4-30</br>';
    }
    return err;
}
function validate_txt_2(fieldname, fieldvalue, alphaExp, alphaExp2) {
    /** accept only 0-9 a-z A-Z _ . without space
     eg. var alphaExp1 = /^[0-9a-zA-Z_.]+$/;
     
     eg2. var reg = new RegExp("^[0-9a-zA-Z_.]+$");
     eg3. var reg2 = new RegExp("[0-9a-zA-Z_.]","g");
     */

    var reg = new RegExp("" + alphaExp + ""); // for matching
    var reg2 = new RegExp("" + alphaExp2 + "", "g"); // for strip
    var err = '';
    fieldvalue = fieldvalue.trim();
    if (fieldvalue.match(reg)) { //or if(fieldvalue.match(alphaExp1)){
        //check if fieldvalue contain illegal value
    } else {

        var c = fieldvalue.replace(reg2, '');
        /** - direct method
         var c = fieldvalue.replace(/[^0-9A-Za-z_.]/g,'');
         var d = fieldvalue;
         var e = '';
         for(var i=0;i<c.length;i++){
         e = c.substr(i,1);
         d = d.replace(e,'');
         }
         */
        err += '*<font color="blue">Invalid Char</font> ' + c.trim() + ' <font color="blue">in</font> ' + $('#lbl_' + fieldname).html() + '</br>';
    }
    if (fieldvalue.length >= 4 && fieldvalue.length <= 30) {
        //check if fieldvalue length between 4-30 char
    } else {
        err += '*<font color="blue">Length Of</font> ' + $('#lbl_' + fieldname).html() + ' <font color="blue">out of bound</font> 4-30</br>';
    }
    return err;
}
function masked_tbl(filter) {
    var delete_task = "";
    $(document).ready(function() {
        oTable = $('#tabledata').dataTable({
            "bJQueryUI": true,
            "aLengthMenu": [[25, 50, 100, 200, -1], [25, 50, 100, 200, "All"]],
            "sPaginationType": "full_numbers",
            "iDisplayLength": 25
        });
        oTable.fnFilter(filter);
    });
}
function refresh_tbl(filter, wid) {
    $.ajax({
        type: "POST",
        url: "?f=masked_tbl&wid=" + wid,
        data: {},
        success: function(data) {
            if (data) {
                document.getElementById('masked_tbl_div').innerHTML = data;
                masked_tbl(filter);
            }
        }
    });
}
function return_filter(widget) {
    var i = document.getElementById('masked_' + widget).length;
    var e = document.getElementById('masked_' + widget);
    var name = new Array();
    var value = new Array();
    var rval = '';
    for (var k = 0; k < i; k++)
    {
        value[k] = document.getElementById('masked_' + widget)[k].value;
        name[k] = document.getElementById('masked_' + widget)[k].name;
        if (name[k] == '' && value[k] != '') {
            rval = value[k];
        }
    }
    return rval;
}
function goto_page(widget, id) {
    var filter = return_filter(widget);
    window.location = "?loc=" + widget + "&id_" + widget + "=" + id + "&filter=" + filter;
}
function cancelData(w) {
    var filter = return_filter(w);
    window.location = "?loc=" + w + "&filter=" + filter;
}
function deleteData(w, wid) {
    var res = 0;
    var str = $('form').serialize();
    if (confirm('Are you sure you want to delete this data into the database?')) {
        res = 1;
    } else {
        res = 0;
    }
    if (res == 1) {
        $('#lblinfo_warning').css('color', '#0000ff');
        $('#lblinfo_warning').html('processing.....');
        $.ajax({
            type: "POST",
            url: "?f=workflow_data&remove=1&wid=" + wid,
            data: str,
            success: function(data2) {
                var data =data2;
                if (data.trim()) {
                    if (data.trim() == 'refresh:OK') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Delete successfully.');
                        window.location .reload();
                    } else if (data.trim() == 'OK') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Delete successfully.');
                        var filter = return_filter(w);
                        window.location = "?loc=" + w + "&filter=" + filter;
                    } else {
                        $('#lblinfo_warning').css('color', '#ff0000');
                        $('#lblinfo_warning').html('*Error :' + data);
                    }
                } else {
                    $('#lblinfo_warning').css('color', '#ff0000');
                    $('#lblinfo_warning').html('*Error of deleting. Please try again.......');
                }
            }
        });
    }
}

function savaData(w, wid) {
    var module1 = '';
    var str = $('form').serialize();
    var b = false;
    var c = false;
    var err = '';
    var tmp = '';
    var fields = $(':input').serializeArray();
    jQuery.each(fields, function(i, field) {
        b = $('#lbl_' + field.name).hasClass('mandatory');
        if (b == true) {
            if (field.value == '') {
                module1 += field.name + ',';
                $('#lbl_' + field.name).css('color', '#ff0000');
            } else {
                if (window.checkvalidation) {
                    tmp = checkvalidation(field.name, field.value);
                    if (tmp != '') {
                        c = false;
                        err = err + tmp + '</br>';
                    } else {
                        c = true;
                    }
                } else {
                    c = true;
                }
                if (c == true) {
                    $('#lbl_' + field.name).css('color', '#999999');
                } else {
                    module1 += field.name + ',';
                    $('#lbl_' + field.name).css('color', '#ff0000');
                }
            }
        }
        if (field.name == 'workflow_selector[]') {
            str = str + '&' + field.value + '=1';
        }
        //$('#results').append(field.name + ":" + field.value + ";" + b + "</br>");
    });
    if (err != '') {
        $('#lblinfo_warning').css('color', '#ff0000');
        $('#lblinfo_warning').html(err);
    } else if (module1 != '') {
        $('#lblinfo_warning').css('color', '#ff0000');
        $('#lblinfo_warning').html('*Please fill in all module information in red');
    } else {
        $('#lblinfo_warning').css('color', '#0000ff');
        $('#lblinfo_warning').html('processing.....');
        $.ajax({
            type: "POST",
            url: "?f=workflow_data&wid=" + wid,
            data: str,
            success: function(data2) {
                var data =data2;
               // alert(data.trim());
                if (data.trim()) {
                    if (data.trim() == 'refresh:OK:ADD') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Save successfully.');
                        window.location.reload();
                    } else if (data.trim() == 'OK:ADD') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Save successfully.');
                        if (window.refresh_tbl) {
                            var filter = return_filter(w);
                            refresh_tbl(filter, wid);
                        }
                        $('#save_btn').css('visibility', 'hidden');
                    } else if (data.trim() == 'refresh:OK:UPD') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Save successfully.');
                        window.location.reload();
                    }else if (data.trim() == 'OK:UPD') {
                        $('#lblinfo_warning').css('color', '#0000ff');
                        $('#lblinfo_warning').html('Save successfully.');
                        if (window.refresh_tbl) {
                            var filter = return_filter(w);
                            refresh_tbl(filter, wid);
                        }
                    } else {
                        $('#lblinfo_warning').css('color', '#ff0000');
                        $('#lblinfo_warning').html('*Error :' + data);
                    }
                } else {
                    $('#lblinfo_warning').css('color', '#ff0000');
                    $('#lblinfo_warning').html('*Error of saving. Please try again.......');
                }
            }
        });
    }
}
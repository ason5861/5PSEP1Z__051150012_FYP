// Login JavaScript Document
function login(link) {
    $("#loginBtn").attr("disabled", "disabled");
    $("#clearBtn").attr("disabled", "disabled");
    var username = $('#username').val();
    var password = $('#password').val();
    var remember_me = $('#remember_me').is(":checked");
    var loc = getQueryVariable('loc');

    $.ajax({
        dataType: 'json',
        type: 'POST',
        url: '?q=loginAction',
        data: {
            username: username,
            password: password,
            remember_me: remember_me
        },
        success: function (data) {
            if (data.result == true) {
                if (data.blackbox != '') {
                    window.location = '?system=blackbox';
                } else {
                    window.location = '?loc=' + loc;
                }
            } else {
                $("#loginBtn").removeAttr("disabled");
                $("#clearBtn").removeAttr("disabled");
                $("#login_error").fadeIn(300);
                $("#login_error").html('<span class="i_warning">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="vertical-align:middle;">Wrong Username And Password. Please Try Again.</span>');
                $("#login_error").fadeOut(10000);
            }
        },
        error: function (jqXHR, exception) {
            // alert("stauts:"+jqXHR.status);
        }
    });
}
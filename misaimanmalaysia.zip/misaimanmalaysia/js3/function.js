function detect_enter(objEvent, callback, keyval_1) {
    var iKeyCode;
    iKeyCode = objEvent.keyCode ? objEvent.keyCode : (objEvent.which ? objEvent.which : objEvent.charCode);
    if (iKeyCode == 13) {
        if (arguments[2]) {
            callback(arguments[2]);
        }
        else {
            if (keyval_1 != '') {
                callback(keyval_1);
            } else {
                callback();
            }
        }
    }
}
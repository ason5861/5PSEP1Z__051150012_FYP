<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Delicious - Food Blog Template | Home</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <!--<div id="preloader">
        <i class="circle-preloader"></i>
        <img src="img/core-img/salad.png" alt="">
    </div>-->

    <!-- Search Wrapper -->
    <div class="search-wrapper">
        <!-- Close Btn -->
        <div class="close-btn"><i class="fa fa-times" aria-hidden="true"></i></div>


    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-between">
                    <!-- Breaking News -->
                    <div class="col-12 col-sm-6">
                        <div class="breaking-news">
						
                            <div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    <li><a href="#">Hello Value Customer!</a></li>
                                    <li><a href="#">Welcome to Misai Man Herbal Tea World</a></li>
									<li><font color="blue"><i><strong>Today's date is :<span id="time"></span></strong></font></i></li>
                                    <!--  <li><a href="#">Hello Delicious!</a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Top Social Info -->
                    <div class="col-12 col-sm-6">
                        <div class="top-social-info text-right">
                        <!--     <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>-->
                            <a href="https://www.facebook.com/misaimanmalaysia/?modal=admin_todo_tour"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                         <!--    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>-->
                         <!--    <a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a>-->
                          <!--   <a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a>-->
                         <!--   <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="delicious-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="deliciousNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.php"><img src="img/core-img/misai_man_logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                    </nav>
                </div>
            </div>
        </div>
    </header>
    

<BODY>
<div id="shopping-cart">
<div class="txt-heading"><strong>Order Details</strong></div><br>

<?php

?>	


<?php	
require_once("conf/dbcontroller.php");
//echo  "INSERT INTO  `order`  (`name`, `phoneNumber`, `email`, `remark`, `total`) VALUES ('".$_POST['name']."','".$_POST['pn']."','".$_POST['email']."','".$_POST['remark']."',".$_POST['total'].")";
$db_handle = new DBController();
$orderDetail ;
if(!empty($_GET["action"])) {
    switch($_GET["action"]) {
        case "accept":
            if(!empty($_GET["id"])) {
               $db_handle->updatetQuery("UPDATE `order` SET `status`=1 WHERE `id`=".$_GET["id"]);
            }
        break;
        case "reject":
            if(!empty($_GET["id"])) {
                $db_handle->updatetQuery("UPDATE `order` SET `status`=2 WHERE `id`=".$_GET["id"]);
             }   
        break;
        case "view":
        if(!empty($_GET["id"])) {
            $orderDetail =$db_handle->runQuery("SELECT * FROM orderproduct o LEFT JOIN tblproduct p ON o.product = p.code where o.order =".$_GET["id"]);
         }
        break;	
    }
    }

$productByCode = $db_handle->runQuery("SELECT * FROM `order` WHERE 1 ");

if (empty($_GET["action"])||($_GET["action"]!= "view"))
{
?>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th>No</th>
<th>Name</th>
<th >Phone number</th>
<th >Email</th>
<th >Remark</th>
<th >Address</th>
<th >Total</th>
<th >Status</th>
<th >Create Date Time</th>
<th >Action</th>
</tr>	
<?php
	$i= 1;
    foreach ($productByCode as $item){
			
		?>
				<tr style="
                        height: 45px;
                    ">
				<td><?php echo $i++; ?></td>
				<td><?php echo $item["name"]; ?></td>
				<td><?php echo $item["phoneNumber"]; ?></td>
				<td ><?php echo $item["email"]; ?></td>
				<td ><?php echo $item["address"]; ?></td>
				<td ><?php echo $item["remark"]; ?></td>
                <td ><?php echo "RM ". $item["total"]; ?></td>
                <td ><?php   switch($item["status"]){
                case 0:
                echo "pending";
                break;
                case 1:
                echo "accept"; 
                break;
                case 2:
                echo "reject";
                break;

                } ?></td>
                <td ><?php echo  $item["created"]; ?></td>
                <td >
                    <a  id="btn"  href="admin.php?action=accept&id=<?php echo $item['id'] ?>" >Accept</a>
                    <a  id="btn"  href="admin.php?action=reject&id=<?php echo $item['id'] ?>" >Reject</a>
                    <a  id="btn"  href="admin.php?action=view&id=<?php echo $item['id'] ?>" >View</a>
                </td>
                </tr>


				<?php
        }
      ?>  </tbody>
        </table><?php
    }else{
?>

<a id="btnEmpty" href="admin.php">Back</a>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th>No</th>
<th>Name</th>
<th >Quatity</th>
<th >Cost</th>
<th >Price</th>
</tr>

<?php
 $i= 1;
 foreach ($orderDetail as $item){
    ?>
            <tr style="
                    height: 45px;
                ">
			<td><?php echo $i++; ?></td>
            <td><?php echo $item["name"]; ?></td>
            <td><?php echo $item["quatity"]; ?></td>
            <td ><?php echo $item["cost"]; ?></td>
            <td ><?php echo $item["price"]; ?></td>
            </tr>
      

            <?php
    }
    ?>  </tbody>
    </table><?php
    }
		?>
		
	

<hr>
<div class="txt-heading"><strong>Contact Us Details</strong></div><br>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th>No</th>
<th>Name</th>
<th >Subject</th>
<th >Message</th>
<th >Email</th>
<th >Created Date Time</th>
</tr>	

<?php
$i=1;
$productByCode = $db_handle->runQuery("SELECT * FROM `contact` WHERE 1 ");	
    foreach ($productByCode as $item){
		?>
				<tr style="
                        height: 45px;
                    ">
				<td><?php echo $i++; ?></td>
				<td><?php echo $item["name"]; ?></td>
				<td><?php echo $item["subject"]; ?></td>
				<td ><?php echo $item["message"]; ?></td>
				<td ><?php echo $item["email"]; ?></td>
                <td ><?php echo $item["created"]; ?></td>
                </tr>


				<?php
        }
      ?>  </tbody>
        </table>

<div style="
    display: grid;
    width: 100%;
    background-color: red;
"></div>
       <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-12 h-100 d-flex flex-wrap align-items-center justify-content-between">

                    <!-- Copywrite -->
                    <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with by <a href="https://www.facebook.com/misaimanmalaysia/" target="_blank">Misai Man</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                </div>
            </div>
        </div>
    </footer>
</BODY>
</HTML>
	
	
	
	
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>

<script>
$(document).ready(function () {
  $('#dtBasicExample').DataTable();
  $('.dataTables_length').addClass('bs-select');
});


</script>

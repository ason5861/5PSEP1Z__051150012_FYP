<?php

$host = "localhost";
$username = "root";
$password = "";
$schema = "delicious_new";
$db = mysqli_connect($host, $username, $password);
mysqli_set_charset('utf8', $db);
if (!mysqli_select_db($schema, $db)) {
	echo "";
    // exit;
}
?>